import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import Markdown from 'react-markdown';
import { Send, Terminal, KeyRound, Loader2, Search, Check, Copy, Share2, MessageSquarePlus, ImagePlus, X, Youtube, SquarePen, Sparkles, History, Image as ImageIcon, TrendingUp, Lightbulb, ArrowUp, SlidersHorizontal, Settings2, Bookmark, LineChart } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { ai, QUANTMASTER_SYSTEM_PROMPT, QUANTMASTER_TOOLS } from './lib/gemini';
import { shareSnippet, getSnippet } from './lib/firebase';
import { lintPineScript, LintIssue } from './lib/linter';
import { AlertCircle } from 'lucide-react';
import ChartWidget from './components/ChartWidget';

const SearchableCodeBlock = ({ codeString, language, props }: { codeString: string, language: string, props: any }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [matches, setMatches] = useState<number[]>([]);
  const [currentMatch, setCurrentMatch] = useState(-1);

  const lintIssues = useMemo(() => {
    if (language === 'typescript') {
      return lintPineScript(codeString);
    }
    return [];
  }, [codeString, language]);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    if (!term.trim()) {
      setMatches([]);
      setCurrentMatch(-1);
      return;
    }
    const lines = codeString.split('\n');
    const foundMatches: number[] = [];
    lines.forEach((line, idx) => {
      if (line.toLowerCase().includes(term.toLowerCase())) {
        foundMatches.push(idx);
      }
    });
    setMatches(foundMatches);
    setCurrentMatch(foundMatches.length > 0 ? 0 : -1);
  };

  const linePropsCallback = useCallback((lineNumber: number) => {
    // lineProps exposes 1-indexed numbers
    const lineIndex = lineNumber - 1;
    const issue = lintIssues.find(i => i.line === lineIndex);
    
    if (issue) {
      return {
        style: { display: 'block', backgroundColor: 'rgba(239, 68, 68, 0.15)', borderLeft: '3px solid #ef4444', paddingLeft: '0.5rem' },
        title: issue.message,
        className: "error-line group/line",
      };
    }
    
    return {
      style: { display: 'block', paddingLeft: '0.5rem' }
    };
  }, [lintIssues]);

  const handleFixErrors = () => {
    const formattedErrors = lintIssues.map(i => `Line ${i.line + 1}: ${i.message}`).join('\n');
    const prompt = `Please pinpoint and fix the following linter errors in my script:\n\nErrors:\n${formattedErrors}\n\nCode:\n\`\`\`${language}\n${codeString}\n\`\`\``;
    window.dispatchEvent(new CustomEvent('send-chat-message', { detail: { message: prompt } }));
  };

  return (
    <div className="relative group overflow-hidden rounded-xl border border-white/10 my-4 text-sm code-font shadow-lg flex flex-col">
      <div className="flex items-center justify-between px-4 py-2 bg-[#0a0a0c] border-b border-white/5">
        <div className="flex items-center space-x-3 w-full sm:w-auto overflow-hidden pr-2">
          <span className="text-[10px] flex-shrink-0 font-bold text-gray-500 uppercase tracking-widest">{language}</span>
          <div className="h-3 w-px flex-shrink-0 bg-white/10" />
          <div className="flex items-center bg-[#18181a] rounded-md px-2 py-0.5 border border-white/5 focus-within:border-[#00ffa3]/30 transition-colors w-full min-w-0">
            <Search className="w-3 h-3 flex-shrink-0 text-gray-500 mr-1.5" />
            <input 
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              className="bg-transparent text-[11px] text-gray-300 outline-none w-full min-w-0 placeholder:text-gray-600"
            />
            {matches.length > 0 && (
              <span className="text-[10px] flex-shrink-0 text-gray-500 ml-2">
                {currentMatch + 1}/{matches.length}
              </span>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-1.5 sm:space-x-2 flex-shrink-0 ml-2">
          <SaveVersionButton codeString={codeString} language={language} />
          <ShareButton codeString={codeString} language={language} />
          <CopyButton codeString={codeString} />
        </div>
      </div>
      <div className="relative">
        {lintIssues.length > 0 && (
          <button 
            onClick={handleFixErrors}
            className="absolute top-2 right-4 z-10 flex items-center bg-red-500/10 hover:bg-red-500/20 transition-colors text-red-400 border border-red-500/20 px-2 py-1 rounded text-[10px] font-bold cursor-pointer shadow-sm hover:scale-105 active:scale-95"
            title="Send to QuantMaster for fixing"
          >
            <AlertCircle className="w-3 h-3 mr-1.5" />
            Fix {lintIssues.length} Error{lintIssues.length > 1 ? 's' : ''}
          </button>
        )}
        <SyntaxHighlighter
          {...props}
          style={atomDark}
          language={language}
          PreTag="div"
          wrapLines={true}
          lineProps={linePropsCallback}
          customStyle={{ margin: 0, padding: '1rem', background: '#18181a', overflowX: 'auto' }}
        >
          {codeString}
        </SyntaxHighlighter>
      </div>
    </div>
  );
};

const SaveVersionButton = ({ codeString, language }: { codeString: string, language: string }) => {
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    const event = new CustomEvent('save-script-version', { detail: { code: codeString, language } });
    window.dispatchEvent(event);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <button
      onClick={handleSave}
      className={`flex items-center space-x-1.5 px-2 py-1 rounded-md text-[10px] font-bold uppercase transition-all border ${
        saved 
          ? 'bg-[#00ffa3]/20 border-[#00ffa3]/40 text-[#00ffa3]' 
          : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10 hover:text-white'
      }`}
      title="Save Version"
    >
      {saved ? (
        <>
          <Check className="w-3 h-3" />
          <span className="hidden sm:inline">Saved</span>
        </>
      ) : (
        <>
          <Bookmark className="w-3 h-3" />
          <span className="hidden sm:inline">Save</span>
        </>
      )}
    </button>
  );
};

const ShareButton = ({ codeString, language }: { codeString: string, language: string }) => {
  const [sharing, setSharing] = useState(false);
  const [shared, setShared] = useState(false);

  const handleShare = async () => {
    setSharing(true);
    try {
      const snippetId = await shareSnippet(codeString, language);
      const shareUrl = `${window.location.origin}${window.location.pathname}?snippetId=${snippetId}`;
      await navigator.clipboard.writeText(shareUrl);
      setShared(true);
      setTimeout(() => setShared(false), 3000);
    } catch (e) {
      console.error(e);
      alert("Failed to generate share link");
    } finally {
      setSharing(false);
    }
  };

  return (
    <button
      onClick={handleShare}
      disabled={sharing}
      className={`flex items-center space-x-1.5 px-2 py-1 rounded-md text-[10px] font-bold uppercase transition-all border ${
        shared 
          ? 'bg-[#00ffa3]/20 border-[#00ffa3]/40 text-[#00ffa3]' 
          : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10 hover:text-white'
      }`}
      title="Share snippet link"
    >
      {sharing ? (
        <Loader2 className="w-3 h-3 animate-spin" />
      ) : shared ? (
        <>
          <Check className="w-3 h-3" />
          <span className="hidden sm:inline">Copied</span>
        </>
      ) : (
        <>
          <Share2 className="w-3 h-3" />
          <span className="hidden sm:inline">Share</span>
        </>
      )}
    </button>
  );
};

const CopyButton = ({ codeString }: { codeString: string }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(codeString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className={`flex items-center space-x-1.5 px-2 py-1 rounded-md text-[10px] font-bold uppercase transition-all border ${
        copied 
          ? 'bg-[#00ffa3]/20 border-[#00ffa3]/40 text-[#00ffa3]' 
          : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10 hover:text-white'
      }`}
      title="Copy code"
    >
      {copied ? (
        <>
          <Check className="w-3 h-3" />
          <span className="hidden sm:inline">Copied</span>
        </>
      ) : (
        <>
          <Copy className="w-3 h-3" />
          <span className="hidden sm:inline">Copy</span>
        </>
      )}
    </button>
  );
};

interface SavedVersion {
  id: number;
  code: string;
  language: string;
  timestamp: string;
  title: string;
}

interface MessageAttachment {
  type?: 'image' | 'youtube';
  inlineData?: {
    data: string; // Base64 representation without data prefix
    mimeType: string;
  };
  previewUrl?: string; // Used for UI rendering only
  youtubeId?: string;
  url?: string;
}

interface Message {
  role: 'user' | 'model';
  content: string;
  attachments?: MessageAttachment[];
}

const MarkdownComponents = {
  code({ node, inline, className, children, ...props }: any) {
    const match = /language-(\w+)/.exec(className || '');
    const codeString = String(children).replace(/\n$/, '');
    
    if (!inline && match) {
      const lang = (match[1] === 'pine' || match[1] === 'pinescript') ? 'typescript' : match[1];
      return (
        <SearchableCodeBlock 
          codeString={codeString} 
          language={lang} 
          props={props} 
        />
      );
    }
    return <code className="bg-white/10 rounded px-1.5 py-0.5 text-sm" {...props}>{children}</code>;
  }
};

export default function App() {
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('quantmaster_messages_v6');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse messages from local storage", e);
      }
    }
    return [];
  });
  const [input, setInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [pendingAttachments, setPendingAttachments] = useState<MessageAttachment[]>([]);
  const [showYoutubeInput, setShowYoutubeInput] = useState(false);
  const [youtubeInputValue, setYoutubeInputValue] = useState('');
  const [trendingScripts, setTrendingScripts] = useState<any[]>([]);
  const [isFetchingTrending, setIsFetchingTrending] = useState(false);
  const [trendingError, setTrendingError] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [showSaved, setShowSaved] = useState(false);
  const [historyItems, setHistoryItems] = useState<any[]>([]);
  const [savedVersions, setSavedVersions] = useState<SavedVersion[]>(() => {
    const saved = localStorage.getItem('quantmaster_saved_versions');
    return saved ? JSON.parse(saved) : [];
  });
  const [initialSnippetLoaded, setInitialSnippetLoaded] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showChart, setShowChart] = useState(false);
  const [strategyParams, setStrategyParams] = useState({
    lookback: 14,
    smoothing: 2,
    thresholdHigh: 70,
    thresholdLow: 30
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLDivElement>(null);

  // Use a ref to always access latest messages in global event listeners
  const messagesRef = useRef(messages);
  useEffect(() => { messagesRef.current = messages; }, [messages]);

  const sendAiMessage = async (userMessage: string, attachments: MessageAttachment[] = []) => {
    if ((!userMessage.trim() && attachments.length === 0) || isLoading) return;

    if (!ai) {
      alert("Please configure your Gemini API Key in the AI Studio Secrets panel.");
      return;
    }

    setMessages((prev) => [
      ...prev, 
      { role: 'user', content: userMessage, attachments: attachments.length > 0 ? attachments : undefined }
    ]);
    setIsLoading(true);

    try {
      setMessages((prev) => [...prev, { role: 'model', content: '' }]);

      // Prepare history for chat
      const historyParts = messagesRef.current
        .filter(m => m.content !== '' || (m.attachments && m.attachments.length > 0))
        .map(m => {
          const parts: any[] = [];
          if (m.content) parts.push({ text: m.content });
          if (m.attachments) {
            m.attachments.forEach(att => {
              if (att.type === 'youtube' && att.url) {
                parts.push({ text: `\n[Reference Video: ${att.url}]\n` });
              } else if (att.inlineData) {
                parts.push({ inlineData: att.inlineData });
              }
            });
          }
          return { role: m.role, parts };
        });
      
      const newParts: any[] = [];
      if (userMessage) newParts.push({ text: userMessage });
      attachments.forEach(att => {
        if (att.type === 'youtube' && att.url) {
          newParts.push({ text: `\n[Reference Video: ${att.url}]\n` });
        } else if (att.inlineData) {
          newParts.push({ inlineData: att.inlineData });
        }
      });

      historyParts.push({
        role: 'user',
        parts: newParts
      });

      // Inject the current strategy parameters as an invisible system context
      const dynamicSystemInstruction = `${QUANTMASTER_SYSTEM_PROMPT}\n\n### CURRENT STRATEGY PARAMETERS (HARDWARE CONSTRAINTS):\nWhenever generating or updating Pine Script, ensure the \`input()\` defaults and logic respect these user settings:\n- Lookback Period: ${strategyParams.lookback}\n- Smoothing Factor: ${strategyParams.smoothing}\n- Upper Threshold: ${strategyParams.thresholdHigh}\n- Lower Threshold: ${strategyParams.thresholdLow}`;

      const executeFunctionCall = async (call: any) => {
        if (call.name === "getTrendingScripts") {
          const res = await fetch("/api/trending-scripts");
          const data = await res.json();
          if (!res.ok) return { error: `Trending Analysis Hub: ${data.error || 'Server structure mismatch'}` };
          return data;
        }
        if (call.name === "fetchScriptSource") {
          const res = await fetch(`/api/fetch-script?url=${encodeURIComponent(call.args.url)}`);
          const data = await res.json();
          if (!res.ok) return { error: `Quantum Retrieval Failure: ${data.error || 'Protected source detection'}` };
          return data;
        }
        if (call.name === "analyzePineScriptCode") {
          return { 
            status: "High-reasoning quantitative audit initialized...", 
            instruction: "Perform a deep-dive line-by-line audit. For every issue found: 1. State the line number. 2. Explain the risk (repainting, memory leak, math error). 3. Provide a 'Refactored v6 Solution' snippet. Focus on repainting in MTF contexts and efficiency in large matrix operations." 
          };
        }
        return { error: "Function not found" };
      };

      let currentContents = [...historyParts];
      let finalResponse: any = null;
      let finished = false;

      // Handle function calling loop
      while (!finished) {
        const response = await ai.models.generateContent({
          model: 'gemini-3.1-pro-preview',
          contents: currentContents,
          config: {
            tools: QUANTMASTER_TOOLS,
            toolConfig: { includeServerSideToolInvocations: true },
            systemInstruction: dynamicSystemInstruction,
            temperature: 0.2,
          },
        });

        const functionCalls = response.functionCalls;
        if (functionCalls && functionCalls.length > 0) {
          const isAnalysis = functionCalls.some(c => c.name === "analyzePineScriptCode");
          const statusText = isAnalysis ? "Analyzing provided code..." : "Monitoring TradingView community scripts...";
          
          setMessages((prev) => {
            const newMessages = [...prev];
            newMessages[newMessages.length - 1].content = `_${statusText}_`;
            return newMessages;
          });

          const modelContent = response.candidates?.[0]?.content;
          if (modelContent) currentContents.push(modelContent as any);

          const functionResponses = await Promise.all(
            functionCalls.map(async (call) => {
              const result = await executeFunctionCall(call);
              return {
                functionResponse: {
                  name: call.name,
                  response: result
                }
              };
            })
          );

          currentContents.push({
            role: 'user',
            parts: functionResponses
          } as any);
          continue;
        }

        finalResponse = response;
        finished = true;
      }

      let fullText = finalResponse.text || '';
      let currentText = '';
      const words = fullText.split(' ');
      for (let i = 0; i < words.length; i++) {
        currentText += (i === 0 ? '' : ' ') + words[i];
        setMessages((prev) => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].content = currentText;
          return newMessages;
        });
        if (i % 5 === 0) await new Promise(r => setTimeout(r, 20));
      }
    } catch (error: any) {
      console.error(error);
      
      let errorMessage = '**Error:** Failed to generate response. Please check your API key or try again.';
      
      // Specifically catch Gemini API Rate Limits (429 Resource Exhausted)
      if (error && error.message && error.message.includes('429')) {
         errorMessage = '**API Quota Exceeded:** You have exceeded your free tier Gemini API limits (Resource Exhausted). Please wait for your quota to reset, or upgrade your API plan at [Google AI Studio](https://aistudio.google.com/app/billing).';
      } else if (error && error.status === 429) {
         errorMessage = '**API Quota Exceeded:** You have exceeded your free tier Gemini API limits (Resource Exhausted). Please wait for your quota to reset, or upgrade your API plan at [Google AI Studio](https://aistudio.google.com/app/billing).';
      }

      setMessages((prev) => [
        ...prev.slice(0, -1),
        { role: 'model', content: errorMessage }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const handleProgrammaticChat = (e: any) => {
      sendAiMessage(e.detail.message, []);
    };
    window.addEventListener('send-chat-message', handleProgrammaticChat);
    return () => window.removeEventListener('send-chat-message', handleProgrammaticChat);
  }, [isLoading]);

  const handleAddYoutube = () => {
    setShowYoutubeInput(true);
  };

  const submitYoutubeUrl = () => {
    if (!youtubeInputValue.trim()) {
      setShowYoutubeInput(false);
      return;
    }
    
    const ytRegex = /(?:https?:\/\/)?(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?(?:.*?&)?v=|embed\/|v\/|shorts\/|live\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i;
    const match = youtubeInputValue.match(ytRegex);
    
    if (match && match[1]) {
      const videoId = match[1];
      const cleanURL = `https://www.youtube.com/watch?v=${videoId}`;
      
      setPendingAttachments(prev => [...prev, {
        type: 'youtube',
        youtubeId: videoId,
        url: cleanURL,
        previewUrl: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`
      }]);
      setYoutubeInputValue('');
      setShowYoutubeInput(false);
    } else {
      alert("Please enter a valid YouTube URL");
    }
  };

  const renderHighlights = (text: string) => {
    const regex = /(```[\s\S]*?```|`[^`]+`)/g;
    const parts = text.split(regex);
    
    return parts.map((part, i) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        return <span key={i} className="text-white bg-white/10 rounded-sm">{part}</span>;
      } else if (part.startsWith('`') && part.endsWith('`')) {
        return <span key={i} className="text-white bg-white/10 rounded-sm">{part}</span>;
      }
      return <span key={i}>{part}</span>;
    });
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
      localStorage.setItem('quantmaster_messages_v6', JSON.stringify(messages));
    }
  }, [messages]);

  const fetchTrending = async () => {
    setIsFetchingTrending(true);
    setTrendingError(null);
    try {
      const res = await fetch("/api/trending-scripts");
      const data = await res.json();
      if (!res.ok) {
        setTrendingError(data.error || "Failed to fetch trending scripts.");
        return;
      }
      if (data && Array.isArray(data.scripts)) {
        setTrendingScripts(data.scripts.slice(0, 20));
      } else if (Array.isArray(data)) {
        setTrendingScripts(data.slice(0, 20));
      }
    } catch (e) {
      console.error("Failed to fetch trending scripts", e);
      setTrendingError("Network error: TradingView is currently unreachable.");
    } finally {
      setIsFetchingTrending(false);
    }
  };

  useEffect(() => {
    const checkSnippet = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const snippetId = urlParams.get('snippetId');
      if (snippetId && !initialSnippetLoaded) {
        setInitialSnippetLoaded(true);
        setIsLoading(true);
        const snippet = await getSnippet(snippetId);
        if (snippet) {
          setMessages([
            { role: 'user', content: `Analyze the shared ${snippet.language} snippet.` },
            { role: 'model', content: `I've loaded the shared ${snippet.language} code for analysis. How would you like me to proceed?\n\n\`\`\`${snippet.language}\n${snippet.code}\n\`\`\`` }
          ]);
        } else {
          alert("Shared snippet not found or link expired.");
        }
        setIsLoading(false);
        // Clean URL without reload
        const newUrl = window.location.origin + window.location.pathname;
        window.history.replaceState({}, '', newUrl);
      }
    };
    checkSnippet();
    fetchTrending();
  }, [initialSnippetLoaded]);

  useEffect(() => {
    const handleSaveScript = (e: any) => {
      const { code, language } = e.detail;
      setSavedVersions((prev) => {
        const newVersion = {
          id: Date.now(),
          code,
          language,
          timestamp: new Date().toISOString(),
          title: `Script Version v${prev.length + 1}`
        };
        const updated = [newVersion, ...prev];
        localStorage.setItem('quantmaster_saved_versions', JSON.stringify(updated));
        
        // Let the user know by opening the saved panel
        setShowSaved(true);
        setShowHistory(false);
        setShowSettings(false);
        
        return updated;
      });
    };
    
    window.addEventListener('save-script-version', handleSaveScript);
    return () => window.removeEventListener('save-script-version', handleSaveScript);
  }, []);

  const loadHistory = () => {
    const savedHistory = localStorage.getItem('quantmaster_history_v6');
    if (savedHistory) {
      setHistoryItems(JSON.parse(savedHistory).reverse());
    }
  };

  const restoreHistory = (item: any) => {
    setMessages(item.messages);
    setShowHistory(false);
  };

  const deleteHistoryItem = (id: number) => {
    const savedHistory = localStorage.getItem('quantmaster_history_v6');
    if (savedHistory) {
      const history = JSON.parse(savedHistory);
      const filtered = history.filter((h: any) => h.id !== id);
      localStorage.setItem('quantmaster_history_v6', JSON.stringify(filtered));
      setHistoryItems(filtered.reverse());
    }
  };

  const deleteSavedVersion = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setSavedVersions(prev => {
      const updated = prev.filter(v => v.id !== id);
      localStorage.setItem('quantmaster_saved_versions', JSON.stringify(updated));
      return updated;
    });
  };

  const restoreSavedVersion = (version: SavedVersion) => {
    setInput(`Please revert the strategy back to this saved version (${version.title}):\n\n\`\`\`${version.language}\n${version.code}\n\`\`\`\n\nLet's continue refining from this baseline.`);
    setShowSaved(false);
    textareaRef.current?.focus();
  };

  const handleNewSession = () => {
    if (messages.length > 0) {
      const savedHistory = localStorage.getItem('quantmaster_history_v6');
      const history = savedHistory ? JSON.parse(savedHistory) : [];
      history.push({
        id: Date.now(),
        date: new Date().toISOString(),
        title: messages[0].content.slice(0, 40) + (messages[0].content.length > 40 ? '...' : ''),
        messages: messages
      });
      localStorage.setItem('quantmaster_history_v6', JSON.stringify(history));
    }
    setMessages([]);
    setSearchQuery('');
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Only image files are currently supported for visual reference.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        // Extract base64 part
        const base64Data = result.split(',')[1];
        setPendingAttachments(prev => [...prev, {
          type: 'image',
          inlineData: { data: base64Data, mimeType: file.type },
          previewUrl: result
        }]);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    // Handle files dropped
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      Array.from(e.dataTransfer.files).forEach(processFile);
      return;
    }

    // Handle URLs dropped (like youtube links or reference text URLs)
    const uriList = e.dataTransfer.getData('text/uri-list');
    const plainText = e.dataTransfer.getData('text/plain');
    
    const textDropped = uriList || plainText;
    
    if (textDropped) {
      const ytRegex = /(?:https?:\/\/)?(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?(?:.*?&)?v=|embed\/|v\/|shorts\/|live\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i;
      const match = textDropped.match(ytRegex);
      
      if (match && match[1]) {
        const videoId = match[1];
        const cleanURL = `https://www.youtube.com/watch?v=${videoId}`;
        
        setPendingAttachments(prev => [...prev, {
          type: 'youtube',
          youtubeId: videoId,
          url: cleanURL,
          previewUrl: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`
        }]);
      } else {
        setInput(prev => prev + (prev ? ' ' : '') + textDropped);
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach(processFile);
    }
  };

  const removePendingAttachment = (indexToRemove: number) => {
    setPendingAttachments(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const userMessage = input.trim();
    const currentAttachments = [...pendingAttachments];
    
    setInput('');
    setSearchQuery(''); 
    setPendingAttachments([]); 
    
    await sendAiMessage(userMessage, currentAttachments);
  };

  const displayedMessages = searchQuery
    ? messages.filter((m) => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  const hasMessages = messages.length > 0;

  return (
    <div className="flex flex-col-reverse md:flex-row h-[100dvh] bg-[#1e1e20] text-[#e2e8f0] font-sans antialiased overflow-hidden">
      {/* Sidebar matching the image */}
      <aside className="h-[60px] md:h-[100dvh] w-full md:w-[64px] bg-[#1a1a1c] border-t md:border-t-0 md:border-r border-[#2d2d2e] flex flex-row md:flex-col items-center justify-around md:justify-start md:py-4 flex-shrink-0 z-50 md:pb-0 pb-[env(safe-area-inset-bottom)]">
        {/* Logo Icon */}
        <div className="mb-6 cursor-pointer text-white hidden md:block">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 2L2 22h20L12 2z"/>
            <path d="M6 16h12"/>
          </svg>
        </div>
        
        {/* Nav Icons */}
        <div className="flex flex-row md:flex-col items-center justify-around md:justify-start space-x-2 sm:space-x-4 md:space-x-0 md:space-y-5 w-full md:w-auto h-full px-4 md:px-2 md:mt-2">
          <button 
            onClick={() => { 
                setShowChart(!showChart);
                setShowSaved(false);
                setShowHistory(false);
                setShowSettings(false);
            }}
            className={`p-2.5 rounded-xl flex items-center justify-center transition-all group ${showChart ? 'text-[#00ffa3] bg-[#00ffa3]/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`} 
            title="TradingView Chart"
          >
            <LineChart className="w-[18px] h-[18px] group-hover:scale-110 transition-transform"/>
          </button>
          
          <button onClick={handleNewSession} className="p-2.5 text-gray-400 hover:text-white hover:bg-white/5 rounded-xl flex items-center justify-center transition-all group" title="New Chat">
            <SquarePen className="w-[18px] h-[18px] group-hover:scale-110 transition-transform"/>
          </button>
          <button 
            onClick={() => { setShowSaved(!showSaved); setShowHistory(false); setShowSettings(false); }}
            className={`p-2.5 rounded-xl flex items-center justify-center transition-all group ${showSaved ? 'text-[#00ffa3] bg-[#00ffa3]/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`} 
            title="Version History"
          >
            <Bookmark className="w-[18px] h-[18px] group-hover:scale-110 transition-transform"/>
          </button>
          <button 
            onClick={() => { 
              if (!showHistory) loadHistory();
              setShowHistory(!showHistory); 
              setShowSaved(false);
              setShowSettings(false);
            }}
            className={`p-2.5 rounded-xl flex items-center justify-center transition-all group ${showHistory ? 'text-[#00ffa3] bg-[#00ffa3]/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`} 
            title="Previous Chat"
          >
            <History className="w-[18px] h-[18px] group-hover:scale-110 transition-transform"/>
          </button>

          {/* Mobile visible settings toggle */}
          <button 
            onClick={() => { 
              setShowSettings(!showSettings);
              setShowSaved(false);
              setShowHistory(false);
            }}
            className={`p-2.5 rounded-xl flex items-center justify-center transition-all group md:hidden ${showSettings ? 'text-[#00ffa3] bg-[#00ffa3]/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`} 
            title="Strategy Parameters"
          >
            <SlidersHorizontal className="w-[18px] h-[18px] group-hover:scale-110 transition-transform"/>
          </button>
        </div>
        
        <div className="mt-auto mb-4 hidden md:block">
          <button 
            onClick={() => { 
              setShowSettings(!showSettings);
              setShowSaved(false);
              setShowHistory(false);
            }}
            className={`p-2.5 rounded-xl flex items-center justify-center transition-all group ${showSettings ? 'text-[#00ffa3] bg-[#00ffa3]/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`} 
            title="Strategy Parameters"
          >
            <SlidersHorizontal className="w-[18px] h-[18px] group-hover:scale-110 transition-transform"/>
          </button>
        </div>
      </aside>

      {/* Main Container */}
      <div 
        className={`flex-1 flex flex-col h-[calc(100dvh-60px)] md:h-[100dvh] relative transition-colors overflow-hidden ${isDragging ? 'bg-white/5' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {/* Chart Visualization Overlay */}
        {showChart && (
          <div className="absolute right-0 top-0 bottom-0 w-full md:w-[60%] bg-[#1a1a1c] border-l border-[#2d2d2e] z-40 animate-in slide-in-from-right duration-300 shadow-2xl flex flex-col overflow-hidden">
            <div className="p-4 border-b border-[#2d2d2e] flex items-center justify-between bg-[#1a1a1c]">
              <div className="flex items-center">
                <LineChart className="w-4 h-4 mr-2 text-[#00ffa3]" />
                <h2 className="text-xs font-bold text-gray-200 tracking-widest uppercase">
                  Institutional Chart Hub
                </h2>
              </div>
              <button 
                onClick={() => setShowChart(false)}
                className="text-gray-500 hover:text-white p-1 hover:bg-white/5 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex-1 relative bg-[#131722]">
              <ChartWidget theme="dark" />
            </div>

            <div className="p-4 bg-[#1a1a1c] border-t border-[#2d2d2e]">
               <p className="text-[10px] text-gray-500 italic">
                 Note: Use the indicators panel within the chart to overlay technical signals. Published V6 Architect scripts can be searched and added directly.
               </p>
            </div>
          </div>
        )}

        {/* History / Saved Overlay */}
        {(showHistory || showSaved) && (
          <div className="absolute left-0 top-0 bottom-0 w-full md:w-[300px] bg-[#1a1a1c] border-r border-[#2d2d2e] z-40 animate-in slide-in-from-left duration-300 shadow-2xl flex flex-col">
            <div className="p-4 border-b border-[#2d2d2e] flex items-center justify-between bg-[#1a1a1c]">
              <h2 className="text-xs font-bold text-gray-400 tracking-widest uppercase">
                {showHistory ? 'Session History' : 'Saved Scripts'}
              </h2>
              <button 
                onClick={() => { setShowHistory(false); setShowSaved(false); }}
                className="text-gray-500 hover:text-white p-1 hover:bg-white/5 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
              {showHistory && (
                historyItems.length > 0 ? (
                  historyItems.map((item) => (
                    <div 
                      key={item.id}
                      className="group flex items-center w-full bg-transparent hover:bg-white/5 rounded-xl p-2.5 cursor-pointer transition-all border border-transparent hover:border-white/5 relative"
                      onClick={() => restoreHistory(item)}
                    >
                      <div className="flex-1 min-w-0 pr-6">
                        <p className="text-[13px] text-gray-300 font-medium truncate mb-0.5">{item.title || 'Untitled Session'}</p>
                        <p className="text-[10px] text-gray-500">{new Date(item.id).toLocaleDateString()}</p>
                      </div>
                      <button 
                        onClick={(e) => { e.stopPropagation(); deleteHistoryItem(item.id); }}
                        className="opacity-0 group-hover:opacity-100 p-1.5 text-gray-500 hover:text-red-500 transition-all absolute right-2"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="flex flex-col items-center justify-center h-48 opacity-40 text-center px-4">
                    <History className="w-8 h-8 mb-3" />
                    <p className="text-xs">No previous sessions found</p>
                  </div>
                )
              )}

              {showSaved && (
                savedVersions.length > 0 ? (
                  savedVersions.map((version) => (
                    <div 
                      key={version.id}
                      className="group flex flex-col w-full bg-[#252526]/50 hover:bg-[#303031] rounded-xl p-3 cursor-pointer transition-all border border-white/5 relative mb-2"
                      onClick={() => restoreSavedVersion(version)}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <p className="text-[13px] text-[#00ffa3] font-medium truncate">{version.title}</p>
                        <button 
                          onClick={(e) => deleteSavedVersion(version.id, e)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-gray-500 hover:text-red-500 transition-all ml-2"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-[10px] text-gray-500 mb-2">{new Date(version.timestamp).toLocaleString()}</p>
                      <div className="bg-[#18181a] p-2 rounded border border-white/5 h-16 overflow-hidden relative">
                        <pre className="text-[9px] text-gray-400 font-mono code-font">
                          {version.code.split('\n').slice(0, 4).join('\n')}
                        </pre>
                        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-[#18181a] to-transparent pointer-events-none" />
                      </div>
                      <div className="mt-2 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-gray-500 group-hover:text-[#00ffa3] transition-colors">
                        <span>Revert to this state</span>
                        <ArrowUp className="w-3 h-3 rotate-45" />
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="flex flex-col items-center justify-center h-48 opacity-40 text-center px-4">
                    <Bookmark className="w-8 h-8 mb-3" />
                    <p className="text-xs">No version history yet.<br/>Save a script from the chat.</p>
                  </div>
                )
              )}
            </div>
          </div>
        )}

        {/* Global Parameters Overlay */}
        {showSettings && (
          <div className="absolute left-0 top-0 bottom-0 w-full md:w-[300px] bg-[#1a1a1c] border-r border-[#2d2d2e] z-40 animate-in slide-in-from-left duration-300 shadow-2xl flex flex-col">
            <div className="p-4 border-b border-[#2d2d2e] flex items-center justify-between bg-[#1a1a1c]">
              <h2 className="text-xs font-bold text-gray-400 tracking-widest uppercase flex items-center">
                <Settings2 className="w-4 h-4 mr-2" />
                Strategy Parameters
              </h2>
              <button 
                onClick={() => setShowSettings(false)}
                className="text-gray-500 hover:text-white p-1 hover:bg-white/5 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-6">
              <p className="text-xs text-gray-500 leading-relaxed mb-4">
                Adjusting these parameters updates the foundational context for the "V6 Architect". The architect will use these defaults when generating your next indicator.
              </p>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <label className="text-gray-300 font-medium">Lookback Period</label>
                    <span className="text-[#00ffa3] font-mono">{strategyParams.lookback}</span>
                  </div>
                  <input 
                    type="range" min="2" max="100" 
                    value={strategyParams.lookback}
                    onChange={(e) => setStrategyParams({...strategyParams, lookback: parseInt(e.target.value)})}
                    className="w-full accent-[#00ffa3] h-1.5 bg-[#2d2d2e] rounded-lg appearance-none cursor-pointer"
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <label className="text-gray-300 font-medium">Smoothing Factor</label>
                    <span className="text-[#00ffa3] font-mono">{strategyParams.smoothing}</span>
                  </div>
                  <input 
                    type="range" min="1" max="10" step="0.5"
                    value={strategyParams.smoothing}
                    onChange={(e) => setStrategyParams({...strategyParams, smoothing: parseFloat(e.target.value)})}
                    className="w-full accent-[#00ffa3] h-1.5 bg-[#2d2d2e] rounded-lg appearance-none cursor-pointer"
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <label className="text-gray-300 font-medium">Upper Threshold</label>
                    <span className="text-red-400 font-mono">{strategyParams.thresholdHigh}</span>
                  </div>
                  <input 
                    type="range" min="50" max="100" 
                    value={strategyParams.thresholdHigh}
                    onChange={(e) => setStrategyParams({...strategyParams, thresholdHigh: parseInt(e.target.value)})}
                    className="w-full accent-red-400 h-1.5 bg-[#2d2d2e] rounded-lg appearance-none cursor-pointer"
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <label className="text-gray-300 font-medium">Lower Threshold</label>
                    <span className="text-blue-400 font-mono">{strategyParams.thresholdLow}</span>
                  </div>
                  <input 
                    type="range" min="0" max="50" 
                    value={strategyParams.thresholdLow}
                    onChange={(e) => setStrategyParams({...strategyParams, thresholdLow: parseInt(e.target.value)})}
                    className="w-full accent-blue-400 h-1.5 bg-[#2d2d2e] rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>
              
              <button 
                onClick={() => {
                  setInput(`Please refactor the current script using the new hardware parameters: Lookback=${strategyParams.lookback}, Smoothing=${strategyParams.smoothing}, Overbought=${strategyParams.thresholdHigh}, Oversold=${strategyParams.thresholdLow}.`);
                  setShowSettings(false);
                  textareaRef.current?.focus();
                }}
                className="w-full mt-4 py-2 border border-[#00ffa3]/30 bg-[#00ffa3]/10 hover:bg-[#00ffa3]/20 text-[#00ffa3] text-xs font-bold uppercase tracking-wider rounded-lg transition-colors"
              >
                Apply to Chat
              </button>
            </div>
          </div>
        )}

        {isDragging && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#1e1e20]/80 backdrop-blur-sm border-2 border-dashed border-gray-400 m-4 rounded-3xl pointer-events-none">
            <div className="text-center font-bold text-gray-300">
              <ImagePlus className="w-16 h-16 mx-auto mb-4 opacity-80" />
              <p className="text-xl tracking-widest uppercase">Drop Images or Links Here</p>
            </div>
          </div>
        )}

          <div className="flex-1 flex flex-col min-h-0 overflow-y-auto">
            {hasMessages ? (
              // CHAT INTERFACE
              <>
                <header className="sticky top-0 w-full flex items-center justify-end px-6 py-4 pointer-events-none z-10">
                  <div className="flex items-center space-x-2 text-xs text-gray-400 px-3 py-1.5 pointer-events-auto backdrop-blur-md rounded-full bg-black/20 border border-white/5 shadow-sm">
                    <span className="font-semibold tracking-wider text-[10px]">V6 ARCHITECT</span>
                  </div>
                </header>

                <main className="flex-1 px-4 md:px-24 xl:px-48 pb-6 scroll-smooth">
              <div className="max-w-4xl mx-auto space-y-6">
                {displayedMessages.map((message, index) => (
                  <div key={index} className={message.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
                    <div className={message.role === 'user'
                          ? 'max-w-[85%] rounded-[24px] px-5 py-4 bg-[#2a2a2b] text-gray-100 border border-white/5 ml-auto'
                          : 'max-w-[85%] rounded-[24px] px-5 py-4 bg-transparent text-gray-200'}
                    >
                      {message.role === 'model' ? (
                        <div className="prose prose-invert max-w-none">
                          <Markdown components={MarkdownComponents}>
                            {message.content}
                          </Markdown>
                        </div>
                      ) : (
                        <div className="flex flex-col">
                          {message.attachments && message.attachments.length > 0 && (
                            <div className="flex flex-wrap gap-2 mb-3">
                              {message.attachments.map((att, i) => (
                                att.type === 'youtube' && att.url ? (
                                  <a key={i} href={att.url} target="_blank" rel="noopener noreferrer" className="relative group block rounded-xl overflow-hidden w-48 h-32 border border-white/10 shadow-sm">
                                    {att.previewUrl && <img src={att.previewUrl} alt="YouTube" className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />}
                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                      <Youtube className="w-10 h-10 text-red-500 drop-shadow-md" />
                                    </div>
                                  </a>
                                ) : (
                                  <img key={i} src={att.previewUrl} alt="Attached" className="h-32 object-contain rounded-xl border border-white/10 shadow-sm bg-black/20" />
                                )
                              ))}
                            </div>
                          )}
                          {message.content && <div className="whitespace-pre-wrap text-[15px] leading-relaxed">{message.content}</div>}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </main>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-4 pt-10 md:pt-24 pb-8 md:pb-12 overflow-y-auto z-10 w-full">
            <h1 className="text-[24px] md:text-[32px] font-bold mb-6 md:mb-8 text-white text-center tracking-tight px-2">What do you want to create?</h1>
        
        <div className="flex flex-wrap justify-center gap-2 md:gap-3 mb-8 md:mb-12 w-full px-2">
          <button onClick={() => fileInputRef.current?.click()} className="flex items-center space-x-2 px-4 md:px-5 py-2 md:py-2.5 bg-[#252526] hover:bg-[#303031] rounded-full text-[12px] md:text-[13px] text-gray-300 border border-white/5 transition-colors font-medium cursor-pointer flex-shrink-0">
            <ImageIcon className="w-4 h-4"/><span className="mt-0.5 hidden sm:inline">Generate From Image</span><span className="mt-0.5 sm:hidden">Image</span>
          </button>
          <button onClick={fetchTrending} className="flex items-center space-x-2 px-4 md:px-5 py-2 md:py-2.5 bg-[#252526] hover:bg-[#303031] rounded-full text-[12px] md:text-[13px] text-gray-300 border border-white/5 transition-colors font-medium cursor-pointer flex-shrink-0">
            <TrendingUp className="w-4 h-4"/><span className="mt-0.5 hidden sm:inline">{isFetchingTrending ? 'Fetching...' : 'Refresh Trending'}</span><span className="mt-0.5 sm:hidden">{isFetchingTrending ? 'Fetching...' : 'Trending'}</span>
          </button>
          <button onClick={() => { setInput("I'm looking to brainstorm a new breakout strategy using standard deviations and VWAP. Any technical ideas?"); textareaRef.current?.focus(); }} className="flex items-center space-x-2 px-4 md:px-5 py-2 md:py-2.5 bg-[#252526] hover:bg-[#303031] rounded-full text-[12px] md:text-[13px] text-gray-300 border border-white/5 transition-colors font-medium cursor-pointer flex-shrink-0">
            <Lightbulb className="w-4 h-4"/><span className="mt-0.5 hidden sm:inline">Brainstorm Ideas</span><span className="mt-0.5 sm:hidden">Ideas</span>
          </button>
        </div>

            {(trendingScripts.length > 0 || trendingError) && (
              <div className="max-w-4xl w-full px-2">
                <div className="flex items-center justify-between mb-4 md:px-4">
                  <h2 className="text-[10px] md:text-xs font-bold text-gray-500 uppercase tracking-[0.2em]">Trending Now</h2>
                  <div className="h-px flex-1 bg-white/5 ml-2 md:ml-4" />
                </div>

                {trendingError ? (
                  <div className="flex flex-col items-center justify-center p-8 bg-red-500/5 border border-red-500/20 rounded-3xl mx-2">
                     <p className="text-red-400 text-sm font-medium mb-2 text-center">{trendingError}</p>
                     <button 
                       onClick={fetchTrending}
                       className="text-[11px] text-gray-400 hover:text-white uppercase tracking-widest font-bold flex items-center space-x-2 transition-colors px-3 py-1 bg-white/5 rounded-full"
                     >
                       <span>Retry Scraping</span>
                       <ArrowUp className="w-3 h-3 rotate-90" />
                     </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 md:gap-3 px-1 md:px-2">
                    {trendingScripts.map((script, idx) => (
                      <button 
                        key={idx}
                        onClick={() => {
                          setInput(`Analyze and improve this trending script: ${script.title} (${script.link}). How does it compare to a gold standard indicator?`);
                          textareaRef.current?.focus();
                        }}
                        className="flex flex-col items-start p-3 md:p-4 bg-[#252526]/50 hover:bg-[#303031] border border-white/5 rounded-2xl text-left transition-all hover:scale-[1.02] active:scale-[0.98] group"
                      >
                        <div className="flex justify-between w-full mb-1">
                          <span className="text-[12px] md:text-[13px] font-semibold text-white line-clamp-1 group-hover:text-[#00ffa3] transition-colors">{script.title}</span>
                          <ArrowUp className="w-3 h-3 text-gray-600 rotate-45 group-hover:text-[#00ffa3] transition-colors flex-shrink-0 ml-2" />
                        </div>
                        <span className="text-[10px] md:text-[11px] text-gray-500 mb-2 truncate w-full">by {script.author}</span>
                        <p className="text-[10px] md:text-[11px] text-gray-400 line-clamp-2 leading-relaxed h-8">{script.description}</p>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

            {/* INPUT AREA */}
            <div className={`w-full px-2 sm:px-4 pb-2 sm:pb-6 transition-all duration-500 ${hasMessages ? 'md:max-w-3xl xl:max-w-4xl mx-auto sticky bottom-0 bg-gradient-to-t from-[#1e1e20] via-[#1e1e20]/95 to-transparent pt-8' : 'max-w-[760px] mx-auto'}`}>
          
          {pendingAttachments.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3 px-2">
              {pendingAttachments.map((att, idx) => (
                <div key={idx} className="relative group">
                  {att.type === 'youtube' ? (
                     <div className="relative h-16 w-28 rounded-lg overflow-hidden flex items-center justify-center bg-black/60 border border-white/10 shadow-sm">
                       <img src={att.previewUrl} alt="YouTube Pending" className="absolute inset-0 w-full h-full object-cover opacity-60" />
                       <Youtube className="w-6 h-6 text-red-500 relative z-10" />
                     </div>
                  ) : (
                     <img src={att.previewUrl} alt="Pending" className="h-16 w-auto rounded-lg object-cover border border-white/10 shadow-sm" />
                  )}
                  <button 
                    onClick={() => removePendingAttachment(idx)}
                    className="absolute -top-1.5 -right-1.5 bg-[#252526] border border-[#333] text-gray-300 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-all hover:scale-110 z-20 shadow-md"
                  >
                     <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="bg-[#2a2b2e] border border-white/5 rounded-[28px] shadow-2xl transition-all focus-within:border-[#00ffa3]/30 relative p-1 flex items-end">
            {/* Attachment Actions Column */}
            <div className="flex flex-col p-1 mb-1 ml-1 space-y-1">
              <button 
                type="button" 
                onClick={() => fileInputRef.current?.click()} 
                className="p-2 rounded-2xl text-gray-400 hover:text-[#00ffa3] hover:bg-[#00ffa3]/5 transition-all group relative"
                title="Upload Image"
              >
                <ImageIcon className="w-5 h-5 group-hover:scale-110 transition-transform"/>
              </button>
              <button 
                type="button" 
                onClick={handleAddYoutube} 
                className="p-2 rounded-2xl text-gray-400 hover:text-red-500 hover:bg-red-500/5 transition-all group relative"
                title="Add YouTube Link"
              >
                <Youtube className="w-5 h-5 group-hover:scale-110 transition-transform"/>
              </button>
            </div>

            {/* YouTube URL Overlay */}
            {showYoutubeInput && (
              <div className="absolute left-14 bottom-14 z-[100] bg-[#1e1e20] border border-white/10 rounded-2xl p-3 shadow-2xl w-72 animate-in fade-in slide-in-from-bottom-2 duration-200">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-bold text-gray-400 tracking-widest uppercase">Add reference video</span>
                  <button onClick={() => setShowYoutubeInput(false)} className="text-gray-500 hover:text-white">
                    <X className="w-3 h-3" />
                  </button>
                </div>
                <div className="flex space-x-2">
                  <input 
                    autoFocus
                    placeholder="Paste YouTube URL..."
                    value={youtubeInputValue}
                    onChange={(e) => setYoutubeInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && submitYoutubeUrl()}
                    className="flex-1 bg-[#121214] border border-white/5 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00ffa3]/50"
                  />
                  <button 
                    onClick={submitYoutubeUrl}
                    className="bg-white text-black p-2 rounded-xl hover:bg-gray-200 transition-colors"
                  >
                    <ArrowUp className="w-3 h-3 stroke-[3]" />
                  </button>
                </div>
              </div>
            )}

             <form onSubmit={handleSubmit} className="flex-1 flex flex-col relative w-full rounded-[20px]">
               <input type="file" ref={fileInputRef} className="hidden" accept="image/*" multiple onChange={handleFileSelect} />
               
               <div className={`relative grid min-h-[50px] max-h-[300px] w-full overflow-hidden ${isLoading ? 'opacity-50' : ''}`}>
                  <div 
                    ref={highlightRef} 
                    className="col-start-1 row-start-1 w-full whitespace-pre-wrap break-words pl-2 pr-12 py-4 pointer-events-none overflow-y-auto text-[15px] leading-relaxed text-[#e2e8f0]"
                    aria-hidden="true"
                  >
                    {input === '' ? (
                      <span className="text-gray-500">How can QuantMaster assist your strategy today?</span>
                    ) : (
                      renderHighlights(input + (input.endsWith('\n') ? ' ' : ''))
                    )}
                  </div>
                  <textarea
                    ref={textareaRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        if (showYoutubeInput) {
                          submitYoutubeUrl();
                        } else {
                          handleSubmit(e);
                        }
                      }
                    }}
                    onScroll={(e) => {
                      if (highlightRef.current) highlightRef.current.scrollTop = e.currentTarget.scrollTop;
                    }}
                    className="col-start-1 row-start-1 w-full h-full bg-transparent text-transparent caret-[#00ffa3] pl-2 pr-12 py-4 resize-none outline-none overflow-y-auto text-[15px] leading-relaxed"
                    placeholder=""
                    spellCheck={false}
                    disabled={isLoading}
                  />
               </div>

               <div className="flex items-center justify-end px-3 pb-2 pt-1 h-10 w-full mb-1">
                  <button
                    type="submit"
                    disabled={(!input.trim() && pendingAttachments.length === 0) || isLoading}
                    className="p-2 rounded-xl text-[#050507] bg-[#00ffa3] hover:bg-[#00ffa3]/80 disabled:bg-[#2a2a2b] disabled:text-gray-600 transition-all flex items-center justify-center transform active:scale-95 shadow-[0_0_15px_rgba(0,255,163,0.2)]"
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowUp className="w-4 h-4 stroke-[3]" />}
                  </button>
               </div>
             </form>
          </div>
        </div>

          {/* Disclaimer for empty state only */}
          {!hasMessages && (
            <div className="absolute bottom-2 sm:bottom-6 w-full text-center pointer-events-none transition-opacity">
              <p className="text-[#888] text-[10px] sm:text-[11px] px-4">
                Past performance is not indicative of future results. This tool can make errors. Read <span className="text-gray-300 cursor-pointer pointer-events-auto hover:text-white transition-colors">full disclaimer</span>.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
