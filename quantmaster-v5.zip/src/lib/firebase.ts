import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, collection, addDoc, serverTimestamp } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
// Use the firestoreDatabaseId from the config
export const db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId);

// Connection test
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration or connectivity.");
    }
  }
}
testConnection();

export interface SharedSnippet {
  code: string;
  language: string;
  createdAt: any;
  title?: string;
  authorId?: string;
}

export const shareSnippet = async (code: string, language: string, title?: string): Promise<string> => {
  try {
    const docRef = await addDoc(collection(db, 'snippets'), {
      code,
      language,
      title: title || 'Pine Script Snippet',
      createdAt: serverTimestamp(),
      authorId: auth.currentUser?.uid || 'anonymous'
    });
    return docRef.id;
  } catch (error: any) {
    console.error("Error sharing snippet:", error);
    throw new Error(`Failed to share snippet: ${error.message}`);
  }
};

export const getSnippet = async (snippetId: string): Promise<SharedSnippet | null> => {
  try {
    const docRef = doc(db, 'snippets', snippetId);
    const docSnap = await getDocFromServer(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as SharedSnippet;
    }
    return null;
  } catch (error: any) {
    console.error("Error fetching snippet:", error);
    return null;
  }
};
