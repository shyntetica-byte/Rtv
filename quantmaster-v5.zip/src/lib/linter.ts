export interface LintIssue {
  line: number; // 0-indexed
  message: string;
  severity: 'error' | 'warning';
}

export function lintPineScript(code: string): LintIssue[] {
  const issues: LintIssue[] = [];
  const lines = code.split('\n');
  
  let insideLoop = false;
  let loopIndent = 0;

  lines.forEach((line, idx) => {
    // Ignore comments
    if (line.trim().startsWith('//')) return;

    const trimmed = line.trim();
    const indentMatch = line.match(/^\s*/);
    const indent = indentMatch ? indentMatch[0].length : 0;

    // Check loop boundaries based on indentation
    if (insideLoop && indent <= loopIndent && trimmed !== '') {
      insideLoop = false;
    }

    if (trimmed.startsWith('for ') || trimmed.startsWith('while ')) {
      insideLoop = true;
      loopIndent = indent;
    }

    // Rule 1: loop execution
    if (insideLoop && /ta\.\w+/.test(line)) {
      issues.push({
        line: idx,
        message: 'Execution Context Error: Cannot call ta.* historical functions inside dynamic loops.',
        severity: 'error'
      });
    }

    // Rule 1b: if statement historical function execution
    if (/if\s*\(?.*\)?[ \t]*$/.test(line)) {
      // Check next lines for indent... difficult to do stateless line by line here, but we can do a rough check if `ta.` is indented after `if` in the block... 
      // Instead, we will add a note, or look for `ta.` directly. Let's just catch inline `if ... ta.`
      if (/^\s*(if|else\s+if).*ta\.\w+\(/.test(line)) {
        issues.push({
          line: idx,
          message: 'CW10003: Calling ta.* functions inside an if-statement condition can corrupt the historical buffer. Calculate globally.',
          severity: 'warning'
        });
      }
    }

    // Rule: shorttitle length
    const shorttitleMatch = line.match(/shorttitle\s*=\s*(["'])(.*?)\1/);
    if (shorttitleMatch && shorttitleMatch[2].length > 10) {
      issues.push({
        line: idx,
        message: 'SHORT_TITLE_TOO_LONG: The shorttitle is longer than 10 characters and will cause a rendering or compile error.',
        severity: 'error'
      });
    }

    // Rule 2: UDT history reference object.field[1]
    if (/\b\w+\.\w+\[\d+\]/.test(line)) {
      issues.push({
        line: idx,
        message: 'CE10290: Cannot use history-referencing operator on UDT fields directly. Use (object[1]).field instead.',
        severity: 'error'
      });
    }

    // Rule 3: plot inside fill
    if (/fill\s*\([^,]*plot\s*\(/.test(line)) {
      issues.push({
        line: idx,
        message: 'Rendering Error: Cannot call plot() directly inside fill(). Pass explicit plot references instead.',
        severity: 'error'
      });
    }

    // Rule 4: math.tanh missing
    if (/math\.tanh\s*\(/.test(line)) {
      issues.push({
        line: idx,
        message: 'CE10271: math.tanh() is not a native function in Pine Script. Use custom f_tanh() implementation using math.exp().',
        severity: 'error'
      });
    }

    // Rule 5: polyline.new color argument
    if (/polyline\.new\s*\([^)]*color\s*=/.test(line)) {
      issues.push({
        line: idx,
        message: 'CE10120: polyline.new() uses line_color, not color.',
        severity: 'error'
      });
    }

    // Rule 6: plot.style_dashed doesn't exist
    if (/\bplot\.style_dashed\b/.test(line)) {
      issues.push({
        line: idx,
        message: 'CE10272: plot.style_dashed does not exist. Use plot.style_line or plot.style_circles for plots, or use hline.style_dashed for horizontal lines.',
        severity: 'error'
      });
    }

    // Rule 7: matrix.add_row missing index or using named args improperly
    if (/matrix\.add_row\s*\(\s*[^,]+,\s*array\.from/.test(line) || /row\s*=\s*array\.from/.test(line)) {
      issues.push({
        line: idx,
        message: 'CE10123: matrix.add_row() requires an index argument before the array (e.g. matrix.add_row(mat, index, array)). Do not skip the index argument.',
        severity: 'error'
      });
    }
  });

  return issues;
}
