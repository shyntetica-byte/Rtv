import React, { useState, useMemo } from 'react';
import { AdvancedRealTimeChart } from "react-ts-tradingview-widgets";
import { Search, X, Plus, Filter } from 'lucide-react';

interface ChartWidgetProps {
  symbol?: string;
  theme?: 'light' | 'dark';
}

interface Indicator {
  id: string;
  name: string;
  category: string;
}

const AVAILABLE_INDICATORS: Indicator[] = [
  { id: "RSI@tv-basicstudies", name: "Relative Strength Index (RSI)", category: "Oscillators" },
  { id: "MACD@tv-basicstudies", name: "MACD", category: "Trend" },
  { id: "Stochastic@tv-basicstudies", name: "Stochastic", category: "Oscillators" },
  { id: "BollingerBands@tv-basicstudies", name: "Bollinger Bands", category: "Volatility" },
  { id: "MASimple@tv-basicstudies", name: "Moving Average Simple (SMA)", category: "Trend" },
  { id: "MAExp@tv-basicstudies", name: "Moving Average Exponential (EMA)", category: "Trend" },
  { id: "AverageTrueRange@tv-basicstudies", name: "Average True Range (ATR)", category: "Volatility" },
  { id: "IchimokuCloud@tv-basicstudies", name: "Ichimoku Cloud", category: "Trend" },
  { id: "ParabolicSAR@tv-basicstudies", name: "Parabolic SAR", category: "Trend" },
  { id: "Volume@tv-basicstudies", name: "Volume", category: "Volume" },
  { id: "CCI@tv-basicstudies", name: "CCI", category: "Oscillators" },
  { id: "ChaikinOsc@tv-basicstudies", name: "Chaikin Oscillator", category: "Volume" },
];

const ChartWidget: React.FC<ChartWidgetProps> = ({ symbol = "BINANCE:BTCUSDT", theme = "dark" }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIndicatorIds, setSelectedIndicatorIds] = useState<string[]>([]);
  const [showResults, setShowResults] = useState(false);

  const filteredIndicators = useMemo(() => {
    if (!searchTerm.trim()) return AVAILABLE_INDICATORS;
    return AVAILABLE_INDICATORS.filter(ind => 
      ind.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ind.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  const toggleIndicator = (id: string) => {
    setSelectedIndicatorIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
    setSearchTerm("");
    setShowResults(false);
  };

  const removeIndicator = (id: string) => {
    setSelectedIndicatorIds(prev => prev.filter(i => i !== id));
  };

  return (
    <div className="flex flex-col w-full h-full bg-[#131722]">
      {/* Indicator Search Bar */}
      <div className="p-3 bg-[#1e222d] border-b border-white/5 flex flex-col gap-3">
        <div className="flex items-center gap-3">
          <div className="relative flex-1 group">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <Search className="w-3.5 h-3.5 text-gray-500 group-focus-within:text-[#00ffa3] transition-colors" />
            </div>
            <input
              type="text"
              placeholder="Search built-in indicators (SMA, RSI, MACD...)"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setShowResults(true);
              }}
              onFocus={() => setShowResults(true)}
              className="w-full bg-[#2a2e39] border border-white/10 rounded-lg py-2 pl-9 pr-4 text-xs text-white placeholder:text-gray-500 outline-none focus:border-[#00ffa3]/30 transition-all shadow-inner"
            />
            
            {showResults && searchTerm.trim() && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-[#2a2e39] border border-white/10 rounded-lg shadow-2xl z-50 max-h-64 overflow-y-auto custom-scrollbar anim-in-fade-in anim-in-slide-in-from-top-2 duration-200">
                {filteredIndicators.length > 0 ? (
                  filteredIndicators.map((ind) => (
                    <button
                      key={ind.id}
                      onClick={() => toggleIndicator(ind.id)}
                      className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-white/5 text-left transition-colors border-b border-white/5 last:border-0"
                    >
                      <div>
                        <div className="text-xs font-medium text-gray-200">{ind.name}</div>
                        <div className="text-[10px] text-gray-500 uppercase tracking-tighter">{ind.category}</div>
                      </div>
                      {selectedIndicatorIds.includes(ind.id) ? (
                         <X className="w-3 h-3 text-red-400" />
                      ) : (
                         <Plus className="w-3.5 h-3.5 text-[#00ffa3]" />
                      )}
                    </button>
                  ))
                ) : (
                  <div className="p-4 text-center text-xs text-gray-500 italic">No matching indicators found</div>
                )}
              </div>
            )}
            {showResults && (
               <div className="fixed inset-0 z-40" onClick={() => setShowResults(false)} />
            )}
          </div>

          <div className="flex -space-x-1 overflow-hidden">
             {selectedIndicatorIds.slice(0, 3).map((id) => (
               <div key={id} className="inline-block h-6 w-6 rounded-full ring-2 ring-[#1e222d] bg-[#00ffa3]/20 flex items-center justify-center">
                 <Filter className="w-2.5 h-2.5 text-[#00ffa3]" />
               </div>
             ))}
             {selectedIndicatorIds.length > 3 && (
               <div className="flex items-center justify-center h-6 w-6 rounded-full ring-2 ring-[#1e222d] bg-[#2a2e39] text-[9px] font-bold text-gray-400">
                 +{selectedIndicatorIds.length - 3}
               </div>
             )}
          </div>
        </div>

        {selectedIndicatorIds.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {selectedIndicatorIds.map(id => {
              const indicator = AVAILABLE_INDICATORS.find(ind => ind.id === id);
              return (
                <div key={id} className="flex items-center bg-[#00ffa3]/10 border border-[#00ffa3]/20 rounded-full px-2 py-0.5 group">
                  <span className="text-[10px] font-bold text-[#00ffa3] mr-1.5">{indicator?.name.split(' (')[0]}</span>
                  <button 
                    onClick={() => removeIndicator(id)}
                    className="hover:text-red-400 transition-colors"
                  >
                    <X className="w-2.5 h-2.5 text-gray-400" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="flex-1 w-full min-h-[400px] rounded-b-xl overflow-hidden shadow-2xl relative" id="tv-chart-container">
        <AdvancedRealTimeChart
          key={selectedIndicatorIds.join(',')} // Force re-mount to update studies
          symbol={symbol}
          theme={theme}
          autosize
          interval="D"
          timezone="Etc/UTC"
          style="1"
          locale="en"
          toolbar_bg="#1e222d"
          enable_publishing={false}
          hide_side_toolbar={false}
          allow_symbol_change={true}
          container_id="tv-chart-container"
          studies={selectedIndicatorIds as any}
        />
      </div>
    </div>
  );
};

export default ChartWidget;
